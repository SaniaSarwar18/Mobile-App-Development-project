package com.example.quizapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        ImageView questionImage = findViewById(R.id.question_image);
        TextView questionText = findViewById(R.id.question_text);
        Button optionOne = findViewById(R.id.option_one);
        Button optionTwo = findViewById(R.id.option_two);
        Button optionTwo = findViewById(R.id.option_three)                                                                           Button optionTwo = findViewById(R.id.option_four)
        // Optionally, set up listeners for buttons here
    }
}